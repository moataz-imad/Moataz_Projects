def sparkSqlQuery2(query,mapping,glueContext=glueContext,ctx='') -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext,ctx)

def generate_uuid7():
    uuid_value = uuid7()
    return str(uuid_value)

# new uuid_v7 function:
def add_field(dynamicFrame,name='id', value=uuid_udf(),glueContext=glueContext) -> DynamicFrame:
    '''Adds a new field to the dynamic frame. (without changing to dataframe)
    '''
    temp_df=dynamicFrame.toDF().withColumn(name, value)
    final_df=DynamicFrame.fromDF(temp_df, glueContext, dynamicFrame.name)
    
    res=sparkSqlQuery(
        query=f'SELECT * from df order by {name}',
        mapping={"df": final_df})
    return  res

def read_table(env,table):
    db_mapping = {
        "legacy_dev": "d1i68u267en03_public",
        "legacy_test": "d4gr3vvu9sgjmb_public",
        "legacy_prod": "d1cvvg3b7kqn86_public",
        "hrahub1": "tchdatabase",
        "hrahub_staging": "tchdatabase",
        "hrahub_prod": "tchdatabase",
        "bigquery":"key-chalice-340021"
    }
    db = db_mapping.get(env, "ERROR")
    if db=="ERROR":
        print("Invalid Environment:",env)
        return
    elif env=="bigquery":
        try:
            temp_df = glueContext.create_dynamic_frame.from_options(
                connection_type=env,
                connection_options={
                    "connectionName": env,
                    "parentProject": db,
                    "table": table,
                    "viewsEnabled": "true"})
            return temp_df
        except:
            print(f'ERROR: check if table {table} exists, or if connection to {env} was established')
            
    else:
        try:
            temp_df=glueContext.create_dynamic_frame.from_catalog(
                    database=env,
                    table_name=f"{db}_{table}")

            return temp_df
        except:
            print(f'ERROR: check if table {table} exists, or if connection to {env} was established')

def write_table(env,table,frame):
    db_mapping = {
        "legacy_dev": "d1i68u267en03_public",
        "legacy_test": "d4gr3vvu9sgjmb_public",
        "legacy_prod": "d1cvvg3b7kqn86_public",
        "hrahub": "tchdatabase",
        "hrahub_staging": "tchdatabase",
        "hrahub_prod": "tchdatabase"
    }
    db = db_mapping.get(env, "ERROR")
    if db=="ERROR":
        print("Invalid Environment:",env)
        return
    glueContext.write_dynamic_frame.from_catalog(
        frame=frame,
        database=env,
        table_name=f"{db}_{table}"
    )
    return 
